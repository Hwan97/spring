echo "If you already installed, All data will be initialized "
echo "Your IP Address is as follows."
echo "If not match, correct /etc/hosts file. "
echo "================================================ "
./testmyip
echo "================================================ "
echo "Is it ok ?(y/n)"
read response
if test "$response" = y
then
	echo "Type Your SiteID(12 chars :822000001000 for demo only)!!! ==> "
	read response
	mkdir tmp txt audit client group DB regf finfo > /dev/NULL 2>&1
	mkdir jjupdate client/dist finfobk swmt unix version > /dev/NULL 2>&1
	chmod 777 tmp txt audit client group DB regf finfo > /dev/NULL 2>&1
	chmod 777 jjupdate client/dist finfobk swmt unix version > /dev/NULL 2>&1
	cp  -f license.txt swmt/license.txt
	cp  -f errcond.txt unix/errcond.txt
	chmod 700 pnwbld
	chmod 700 addinetd
	chmod 700 addsrvcs
	tar cf DBold.tar DB
	mkdir DB > /dev/NULL 2>&1
	./pnwbld $response
	os=`uname -r`

	if expr $os : 5.5 > /dev/null
	then
		cp -f jjpdone_5 jjpdone
		cp -f jjpdtwo_5 jjpdtwo
	fi
	if expr $os : 5.6 > /dev/null
	then
		cp -f jjpdone_6 jjpdone
		cp -f jjpdtwo_6 jjpdtwo
	fi
	if expr $os : 5.7 > /dev/null
	then
		cp -f jjpdone_7 jjpdone
		cp -f jjpdtwo_7 jjpdtwo
	fi
	if expr $os : 5.8 > /dev/null
	then
		cp -f jjpdone_8 jjpdone
		cp -f jjpdtwo_8 jjpdtwo
	fi

	echo "Type loginid for running authority (root)!!! ==> "
	read response
	if test "$response" > " "
	then
		chown -R $response .
	fi
	./addinetd $response
	echo "Type port to use (4555)!!! ==> "
	read response
	./addsrvcs $response
	./inetrsrt
	echo " Installation finished "
else
	echo "Type Correct IP Address of this system !!! ==> "
	read ipaddr
	echo "Type Your SiteID(12 chars :822000001000 for demo only)!!! ==> "
	read response
	mkdir tmp txt audit client group DB regf finfo > /dev/NULL 2>&1
	mkdir jjupdate client/dist finfobk swmt unix version > /dev/NULL 2>&1
	chmod 777 tmp txt audit client group DB regf finfo > /dev/NULL 2>&1
	chmod 777 jjupdate client/dist finfobk swmt unix version > /dev/NULL 2>&1
	cp  -f license.txt swmt/license.txt
	cp  -f errcond.txt unix/errcond.txt
	chmod 700 pnwbld
	chmod 700 addinetd
	chmod 700 addsrvcs
	tar cf DBold.tar DB
	mkdir DB > /dev/NULL 2>&1
	./pnwbld $response $ipaddr
	os=`uname -r`

	if expr $os : 5.5 > /dev/null
	then
		cp -f jjpdone_5 jjpdone
		cp -f jjpdtwo_5 jjpdtwo
	fi
	if expr $os : 5.6 > /dev/null
	then
		cp -f jjpdone_6 jjpdone
		cp -f jjpdtwo_6 jjpdtwo
	fi
	if expr $os : 5.7 > /dev/null
	then
		cp -f jjpdone_7 jjpdone
		cp -f jjpdtwo_7 jjpdtwo
	fi
	if expr $os : 5.8 > /dev/null
	then
		cp -f jjpdone_8 jjpdone
		cp -f jjpdtwo_8 jjpdtwo
	fi

	echo "Type loginid for running authority (root)!!! ==> "
	read response
	if test "$response" > " "
	then
		chown -R $response .
	fi
	./addinetd $response
	echo "Type port to use (4555)!!! ==> "
	read response
	./addsrvcs $response
	./inetrsrt
	echo " Installation finished "
fi
